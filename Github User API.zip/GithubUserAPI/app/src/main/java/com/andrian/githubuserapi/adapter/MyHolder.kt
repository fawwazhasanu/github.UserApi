package com.andrian.githubuserapi.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView

class MyHolder (itemView: View) : RecyclerView.ViewHolder(itemView) {
}